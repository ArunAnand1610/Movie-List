import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:movie_list_project/bloc/movieevent.dart';
import 'package:movie_list_project/bloc/movieliststate.dart';
import 'package:movie_list_project/model/moviemodel.dart';
import 'package:movie_list_project/services/apirepostory.dart';

class MovieBloc extends Bloc<MovieEvent, MovieState> {
  final MovieRepository _movieRepository;
  List<MovieDetails> moviesList = <MovieDetails>[];
  MovieBloc(this._movieRepository) : super(MovieLoadingState()) {
    on<LoadMovieEvent>((event, emit) async {
      emit(MovieLoadingState());
      try {
        moviesList = await _movieRepository.getUsers();
        emit(MovieLoadedState(moviesList));
      } catch (e) {
        emit(MovieErrorState(e.toString()));
      }
    });

    on<LoadCatgorySearchEvent>((event, emit) async {
      emit(MovieLoadingState());
      try {
        List<MovieDetails> result = moviesList
            .where((e) => e.originalTitle!
                .toLowerCase()
                .contains(event.type.toLowerCase().trim()))
            .toList();
        print("The result is ${result.length}");
        emit(MovieLoadedState(result));
        if (event.type.isEmpty) {
          moviesList = await _movieRepository.getUsers();
          emit(MovieLoadedState(moviesList));
        } else {
          emit(MovieLoadedState(moviesList));
        }
      } catch (e) {
        print("The data is:$e");
        emit(MovieErrorState(e.toString()));
      }
    });
  }
}
