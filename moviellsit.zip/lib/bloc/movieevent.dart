import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

@immutable
abstract class MovieEvent extends Equatable {
  const MovieEvent();
}

class LoadMovieEvent extends MovieEvent {
  @override
  List<Object?> get props => [];
}


class LoadCatgorySearchEvent extends MovieEvent {
  final String type;
  const LoadCatgorySearchEvent( this.type);

  @override
  List<Object?> get props => [type];
}