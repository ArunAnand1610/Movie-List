import 'dart:convert';
//import 'package:dio/dio.dart';
import 'package:http/http.dart';
import 'package:movie_list_project/model/moviemodel.dart';

class MovieRepository {
  String api_key = "c7af162254f9af621ae833e27e3ee63f";
  String query = "fun";
  String baseUrl = 'https://api.themoviedb.org/3/search/movie';

  Future<List<MovieDetails>> getUsers() async {
    Response response =
        await get(Uri.parse("$baseUrl?api_key=$api_key&query=$query"));

    if (response.statusCode == 200) {
      final List result = jsonDecode(response.body)['results'];
      return result.map((e) => MovieDetails.fromJson(e)).toList();
    } else {
      throw Exception(response.reasonPhrase);
    }
  }

 
}
